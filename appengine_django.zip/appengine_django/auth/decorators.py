# Copyright 2008 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Decorators for the authentication framework."""

from django.http import HttpResponseRedirect

from google.appengine.api import users


def login_required(function):
  """Implementation of Django's login_required decorator.
  
  The login redirect URL is always set to request.path
  """
  def login_required_wrapper(request, *args, **kw):
    if request.user.is_authenticated():
      return function(request, *args, **kw)
    return HttpResponseRedirect(users.create_login_url(request.path))
  return login_required_wrapper
